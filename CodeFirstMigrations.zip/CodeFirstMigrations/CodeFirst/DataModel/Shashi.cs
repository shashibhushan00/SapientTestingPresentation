
"Server=tcp:sql-pricingsolution-dev-000.database.windows.net,1433;Initial Catalog=pricingsolutiondb;Persist Security Info=False;User ID=pricingsolution-admin;Password=Shashi@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"



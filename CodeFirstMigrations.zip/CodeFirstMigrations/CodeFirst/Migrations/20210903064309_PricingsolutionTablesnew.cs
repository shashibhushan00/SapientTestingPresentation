﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CodeFirst.Migrations
{
    public partial class PricingsolutionTablesnew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MarketQuotes_Symbol_SymbolId",
                table: "MarketQuotes");

            migrationBuilder.DropForeignKey(
                name: "FK_Symbol_ApiConfigurations_ThirdPartyApiId",
                table: "Symbol");

            migrationBuilder.DropTable(
                name: "Addresses");

            migrationBuilder.DropTable(
                name: "People");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Symbol",
                table: "Symbol");

            migrationBuilder.RenameTable(
                name: "Symbol",
                newName: "Symbols");

            migrationBuilder.RenameIndex(
                name: "IX_Symbol_ThirdPartyApiId",
                table: "Symbols",
                newName: "IX_Symbols_ThirdPartyApiId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Symbols",
                table: "Symbols",
                column: "SymbolId");

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    EmailId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserRole = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.EmailId);
                });

            migrationBuilder.CreateTable(
                name: "UserGridViews",
                columns: table => new
                {
                    EmailId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    GridViewEncoding = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GridViewName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserGridViews", x => x.EmailId);
                    table.ForeignKey(
                        name: "FK_UserGridViews_Users_EmailId",
                        column: x => x.EmailId,
                        principalTable: "Users",
                        principalColumn: "EmailId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.AddForeignKey(
                name: "FK_MarketQuotes_Symbols_SymbolId",
                table: "MarketQuotes",
                column: "SymbolId",
                principalTable: "Symbols",
                principalColumn: "SymbolId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Symbols_ApiConfigurations_ThirdPartyApiId",
                table: "Symbols",
                column: "ThirdPartyApiId",
                principalTable: "ApiConfigurations",
                principalColumn: "ApiConfigurationId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MarketQuotes_Symbols_SymbolId",
                table: "MarketQuotes");

            migrationBuilder.DropForeignKey(
                name: "FK_Symbols_ApiConfigurations_ThirdPartyApiId",
                table: "Symbols");

            migrationBuilder.DropTable(
                name: "UserGridViews");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Symbols",
                table: "Symbols");

            migrationBuilder.RenameTable(
                name: "Symbols",
                newName: "Symbol");

            migrationBuilder.RenameIndex(
                name: "IX_Symbols_ThirdPartyApiId",
                table: "Symbol",
                newName: "IX_Symbol_ThirdPartyApiId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Symbol",
                table: "Symbol",
                column: "SymbolId");

            migrationBuilder.CreateTable(
                name: "People",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_People", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Addresses",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    City = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Zipcode = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Addresses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Addresses_People_PersonId",
                        column: x => x.PersonId,
                        principalTable: "People",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Addresses_PersonId",
                table: "Addresses",
                column: "PersonId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_MarketQuotes_Symbol_SymbolId",
                table: "MarketQuotes",
                column: "SymbolId",
                principalTable: "Symbol",
                principalColumn: "SymbolId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Symbol_ApiConfigurations_ThirdPartyApiId",
                table: "Symbol",
                column: "ThirdPartyApiId",
                principalTable: "ApiConfigurations",
                principalColumn: "ApiConfigurationId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
